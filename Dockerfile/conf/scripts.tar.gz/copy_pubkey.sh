#/bin/bash

# Generar claves y añadir como autorizada la propia clave pública
echo -e 'y\n' | ssh-keygen -t rsa -P '' -f ~/.ssh/id_rsa
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
chmod 0600 ~/.ssh/authorized_keys
ssh-keyscan 0.0.0.0 >> ~/.ssh/known_hosts
ssh-keyscan localhost >> ~/.ssh/known_hosts
ssh-keyscan $(hostname) >> ~/.ssh/known_hosts

# Copiar la clave pública a todos los esclavos
for slave in $@; do
	sshpass -p root ssh-copy-id $slave -o StrictHostKeyChecking=no
done

# Deshabilitar acceso ssh con contraseña
# sed -ri 's/^PasswordAuthentication\syes/PasswordAuthentication no/' /etc/ssh/sshd_config
# sed -ri 's/^PermitRootLogin\syes/PermitRootLogin without-password/' /etc/ssh/sshd_config
# service sshd restart
