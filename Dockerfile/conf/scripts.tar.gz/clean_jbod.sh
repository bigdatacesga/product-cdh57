#!/bin/bash

# Eliminar rastros previos
# echo -n "Clean the directories of this host ($(hostname)) from the JBOD? [y/n]: "
# read clean
# if (( clean == "y" )); then 
	echo "Cleaning JBOD..."
	for i in $(eval echo {1..$1});
		do 
			echo "Cleaning /data/$i/"
			rm -rf /data/$i/*
		done
# fi
