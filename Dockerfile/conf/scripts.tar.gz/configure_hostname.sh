#!/bin/bash

# Configuración del host
hostname $(hostname); if cat /etc/sysconfig/network | grep -q HOSTNAME=; \
then sed -i "s/HOSTNAME=.*/HOSTNAME=$(hostname)/g" /etc/sysconfig/network; \
else echo "HOSTNAME="$(hostname) >> /etc/sysconfig/network; fi; \
if ! cat /etc/hosts | grep -q "\s$(hostname)$"; \
then echo -e $(hostname -I | awk '{print $1}')"\t"$(hostname) >> /etc/hosts; fi
