#!/bin/bash

# User limits
echo -e "hdfs\t-\tnofile\t32768
hdfs\t-\tnproc\t2048
hbase\t-\tnofile\t32768
hbase\t-\tnproc\t2048" >> /etc/security/limits.conf
