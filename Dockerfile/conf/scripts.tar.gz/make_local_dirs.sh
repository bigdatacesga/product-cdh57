#!/bin/bash

for i in $(eval echo {1..$1});
do
	# Directorios y permisos para DataNode / NameNode
	mkdir -p /data/$i/dfs/dn /data/$i/dfs/nn
	chmod -R 700 /data/$i/dfs
	chown -R hdfs:hdfs /data/$i/dfs
	
	# Directorios y permisos de directorios locales de ZooKeeper
	mkdir -m 700 /data/$i/zookeeper && chown zookeeper:zookeeper /data/$i/zookeeper
	
	# Directorios y permisos de directorios locales de YARN
	# local-dirs
	mkdir -p /data/$i/yarn/local; \
	# log-dirs
	mkdir /data/$i/yarn/logs; \
	# Permissions
	chmod -R 755 /data/$i/yarn; \
	chown -R yarn:yarn /data/$i/yarn
done
